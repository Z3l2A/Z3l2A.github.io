Welcome to a massive collection of registry, shortcuts, PowerShell, and batch file tweaks from MajorGeeks.Com  The majority of these tweaks are for Windows 10 & 11. Windows 7 & 8 will work in many cases, but not supported.

BACKUP -  BACKUP.-  BACKUP! A registry backup should be done before proceeding:
https://www.majorgeeks.com/content/page/how_to_back_up_or_restore_the_windows_registry.html

-------------------------------------------------------------------------------------------------------------
Check out MajorGeeks. Quality software and tutorials since 2001:
https://www.majorgeeks.com/

Donations accepted if you love what we do:
https://www.majorgeeks.com/content/page/donations.html

Check out all these tweaks individually at:
https://www.majorgeeks.com/mg/sortname/majorgeeks_registry_batch_file_tweaks.html

Check out our YouTube channel:
https://www.youtube.com/user/majorgeeks

-------------------------------------------------------------------------------------------------------------

The license for MajorGeeks Windows Tweaks is FREEWARE. You may freely distribute it unaltered, with a link to the developer page.
https://www.majorgeeks.com/mg/sortpopularity/majorgeeks_registry_batch_file_tweaks.html 

Use at Own Risk. Although we have tested these scripts on our own machines it is impossible to test for every configuration or account for every problem out there on the Net. Any use of or reliance on these scripts, the contents of this Site or the information provided will be at your sole risk. We make no representations or warranties whatsoever regarding the software or information contained in this site.