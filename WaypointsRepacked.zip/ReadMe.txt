WorldmapGUI
to
"C:\Program Files (x86)\Funcom\Secret World Legends\Data\Gui\Default\gfx"

;

Waypoints
to
"%USERPROFILE%\AppData\Local\Funcom\SWL\Prefs" there inside INTO your account-name ... e.g. that is then my path "C:\Users\0\AppData\Local\Funcom\SWL\Prefs\ASHADYLLIA"

if you have any saved waypoints in that folder already, mark them all with CTRL + A and rename them with F2 to anything. All files in here with .XML get waypointed!

All operations can be done while being logged-in.
After deployment,
/unloadclip waypoints.swf
/loadclip waypoints.swf
/reloadui
